# Nelson Akuna Portfolio

This is a simple one-page professional portfolio.

## Publish it free with GitHub Pages
1. Create a GitHub account at github.com if you do not already have one.
2. Create a new repository named `nelson-akuna.github.io`.
3. Upload `index.html` from this folder.
4. In the repository, open **Settings → Pages**.
5. Select **Deploy from a branch**, choose `main`, and save.
6. Your portfolio should become available at:
   `https://nelson-akuna.github.io`

If GitHub gives the site a different URL, copy the URL shown in the Pages section and paste it into the Talenta **Portfolio Links** field.
